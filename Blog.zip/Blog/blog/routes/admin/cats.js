/**
 * Created by lemon on 2016/8/31.
 */
//后台分类页路由
var express = require('express');
var router = express.Router();
var MongoClient = require('mongodb').MongoClient;
const DB_STR = 'mongodb://localhost:27017/blog_ime';//mongodb的端口27017
var ObjectId = require('mongodb').ObjectId;

/* 显示后台的分类列表 */
router.get('/', function(req, res) {
    //1.连接数据库,读取添加后的分类列表页面
    MongoClient.connect(DB_STR,function(err,db){
        if(err){
            res.send(err);
            return;
        }
        var c = db.collection('cats');
        c.find().toArray(function (err,result) {
            if(err){
                res.send(err);
                return;
            }
            //渲染后台首页面
            res.render('admin/category-list',{data:result});

        })
    });
});

/* 显示后台的添加列表 */
router.get('/add', function(req, res) {
    //渲染后台添加页面
    res.render('admin/category-add');
});
//编辑

//处理添加分类(提交的表单)
router.post('/add', function (req,res) {
//    1.获取表单内容
        var title = req.body.title;
        var sort = req.body.sort;
//    2.进行验证
//    3,连接数据库,将数据添加到数据库中
    MongoClient.connect(DB_STR, function (err,db) {
        if(err){
            res.send(err);
            return;
        }
        var c = db.collection('cats');//获取集合cats
        c.insert({title:title,sort:sort},function(err,result){
            if(err){
                res.send(err);
                return;
            }
            res.redirect('/admin/cats');
            //res.send('添加分类成功<a href="/admin/cats">返回列表页</a>');
        })

    });

});
//显示编辑分类列表页
router.get('/edit', function (req,res) {
    var id = req.query.id;
//    连接数据库
    MongoClient.connect(DB_STR, function (err,db) {
        if(err){
            res.send(err);
            return;
        }
        var c = db.collection('cats');
        c.find({_id:ObjectId(id)}).toArray(function (err,result) {
            if(err){
                res.send(err);
                return;
            }
            console.log(result);
            res.render('admin/category-edit',{data : result[0]});

        });
    })
});
//处理表单提交的数据 编辑
router.post('/edit', function (req,res) {
    //获取id
    var id = req.body.id;
    var title = req.body.title;
    var sort = req.body.sort;

//    连接数据库,更新数据
    MongoClient.connect(DB_STR, function (err,db) {
        if(err){
            res.send(err);
            return;
        }
        var c = db.collection('cats');
        c.update({_id:ObjectId(id)},{$set:{title:title,sort:sort}}, function(err,result) {
            if(err){
                res.send(err);
                return;
            }
            //console.log(result);
            res.redirect('/admin/cats');
            //res.send('更新成功<a href="/admin/cats">返回列表</a>');

        });
    })

});
//删除分类
router.get('/delete',function(req,res){
    var id = req.query.id;
    MongoClient.connect(DB_STR, function (err,db) {
        if(err){
            res.send(err);
            return;
        }
        var c = db.collection('cats');//获取集合cats
        c.remove({_id:ObjectId(id)},function(err,result){
            if(err){
                res.send(err);
                return;
            }
            res.redirect('/admin/cats');
        })

    });

});


module.exports = router;
