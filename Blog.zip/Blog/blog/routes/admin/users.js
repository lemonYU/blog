var express = require('express');
var router = express.Router();
var MongoClient = require('mongodb').MongoClient;
const DB_STR = 'mongodb://localhost:27017/blog_ime';//mongodb的端口27017
var ObjectId = require('mongodb').ObjectId;

//使用自定义中间件
router.use('/login',checkNotLogin);

/* GET users listing. */
router.get('/login', function(req, res, next) {
  res.render('admin/login');
});
router.post('/signin', function(req,res) {
  var username = req.body.username;
  var pwd = req.body.pwd;
//  连接数据库,比对数据
  MongoClient.connect(DB_STR, function (err,db) {
    if(err){
      res.send(err);
      return;
    }
    var c = db.collection('users');
    //console.log(c);
    c.find({name:username,pwd:pwd}).toArray(function (err,docs) {
      console.log(docs);
      if(err){
        res.send(err);
        return;
      }
      //res.render('admin/users')
      //res.send('连接ok');
    // 判断获取的数组长度
      if(docs.length){
      //  用户名密码正确,放行
        req.session.isLogin=true;
        res.redirect('/admin/index');

      }else{
        //console.log('用户名或者密码有误...');
        //到登录页
        res.redirect('/admin/users/login');
      }
    })
  })
});

//注销
router.get('/logout', function (req,res) {
  req.session.isLogin = null;
  res.redirect('/admin/index');
});

//在访问 http://localhost:3000/admin/users/login 的进行判断。
//通过req.session.isLogin来判断，如果已经登录了，就返回你原先的页面
function checkNotLogin(req,res,next){
  if(req.session.isLogin){
    res.redirect('back');
  }
  next();
}

module.exports = router;
