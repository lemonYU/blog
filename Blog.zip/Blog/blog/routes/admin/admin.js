//后台首页路由
var express = require('express');
var router = express.Router();

/* GET users listing. */
router.get('/', function(req, res) {
  //渲染后台首页面
  res.render('admin/admin');
});

module.exports = router;
