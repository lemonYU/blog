/**
 * Created by lemon on 2016/8/31.
 */
//后台分类添加页路由
var express = require('express');
var router = express.Router();
var MongoClient = require('mongodb').MongoClient;
const DB_STR = 'mongodb://localhost:27017/blog_ime';//mongodb的端口27017
var ObjectId = require('mongodb').ObjectId;

/* 显示后台的文章列表 */
router.get('/', function(req, res){
    //获取文章显示
    MongoClient.connect(DB_STR, function (err,db){
        if(err){
            res.send(err);
            return;
        }
        var c = db.collection('posts');
        c.find().toArray(function (err,docs){
            if(err){
                res.send(err);
                return;
            }
            res.render('admin/artical-list',{data:docs});
        })
    });
    //res.render('admin/artical-list');
});


/* 显示后台的添加文章 */
router.get('/add', function(req, res) {
    MongoClient.connect(DB_STR, function (err,db){
        if(err){
            res.send(err);
            return;
        }
        var c = db.collection('cats');
        c.find().toArray(function (err,docs){
            if(err){
                res.send(err);
                return;
            }
            res.render('admin/artical-add',{data:docs});
        })
    });
});
//处理表单提交
router.post('/add', function (req,res) {
    var cat = req.body.cat;
    var title = req.body.title;
    var summary = req.body.summary;
    var content = req.body.content;
    var time = new Date();
    var post = {
        cat:cat,
        title:title,
        summary:summary,
        content:content,
        time:time
    };
    //console.log(post);
//    连接数据库,添加数据
    MongoClient.connect(DB_STR, function(err,db) {
        if(err){
            res.send(err);
            return;
        }
        var c = db.collection('posts');
        c.insert(post, function (err,docs) {
            if(err){
                res.send(err);
                return;
            }
            //console.log(docs);
            res.send('添加成功<a href="/admin/posts">查看文章列表</a>')

            //res.render('admin/artical-list');

        })
    })
});
//编辑功能
router.get('/edit', function (req,res) {
    var id = req.query.id;
//    根据_id获取编辑的项的文章分类
    MongoClient.connect(DB_STR, function (err,db) {
        if(err){
            res.send(err);
            return;
        }
        var c = db.collection('cats');
        c.find().toArray(function (err,docs) {
            if(err){
                res.send(err);
                return;
            }
            var c1 = db.collection('posts');
            c1.find({_id:ObjectId(id)}).toArray(function (err,result) {
                if(err){
                    res.send(err);
                    return;
                }
                console.log(result[0]);//渲染页面,加入该文章的初始内容
                res.render('admin/artical-edit',{data:docs,data1:result[0]});
            })
        });

    })
});
router.post('/edit', function (req,res) {
//    获取表单的内容

    var id = req.body.id;
    var cat = req.body.cat;
    var title = req.body.title;
    var summary = req.body.summary;
    var content = req.body.content;
    var time = new Date();
    //console.log(content,id);
//    连接数据库,得到数据,渲染页面
    MongoClient.connect(DB_STR, function (err,db) {
        if(err){
            res.send(err);
            return;
        }
        var c1 = db.collection('posts');
        c1.update({_id:ObjectId(id)},{$set:{cat:cat,title:title,summary:summary,content:content,time:time}},function(err,docs){
            if(err){
                res.send(err);
                return;
            }
            res.redirect('/');
        });
    });

});
//删除文章
router.get('/delete', function (req,res) {
    var id = req.query.id;
    MongoClient.connect(DB_STR, function (err,db) {
        if(err){
            res.send(err);
            return;
        }
        var c = db.collection('posts');
        c.remove({_id:ObjectId(id)}, function (err,docs) {
            if(err){
                res.send(err);
                return;
            }
            res.redirect('/admin/posts');
        })
    })
});

module.exports = router;