var express = require('express');
var router = express.Router();
var MongoClient = require('mongodb').MongoClient;
const DB_STR = 'mongodb://localhost:27017/blog_ime';//mongodb的端口27017
var ObjectId = require('mongodb').ObjectId;

/* GET users listing. */
router.get('/', function(req, res) {
  var id = req.query.id;
  MongoClient.connect(DB_STR,function(err,db){
    if(err){
      res.send(err);
      return;
    }
    //获取文章
    var c = db.collection('posts');
    c.find({_id:ObjectId(id)}).toArray(function (err,docs) {
      if(err){
        res.send(err);
        return;
      }
      //console.log(docs);
      //获取分类
      var c1 = db.collection('cats');
      c1.find().toArray(function (err,result) {
        if (err) {
          res.send(err);
          return;
        }
        //res.send('ok');
        //console.log(result);
        //渲染后台首页面
        res.render('home/article', {data : docs[0], data1:result});

      });
    })
  });
});

module.exports = router;
