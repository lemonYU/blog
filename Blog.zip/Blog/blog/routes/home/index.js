var express = require('express');
var router = express.Router();
var MongoClient = require('mongodb').MongoClient;
const DB_STR = 'mongodb://localhost:27017/blog_ime';//mongodb的端口27017

/* GET home page. */

router.get('/', function(req, res, next) {
  //连接数据库,获取数据,显示到页面
  /*
  MongoClient.connect(DB_STR,function(err,db){
    if(err){
      res.send(err);
      return;
    }
    //获取文章
    var c = db.collection('posts');
    c.find().toArray(function (err,docs) {
      if(err){
        res.send(err);
        return;
      }
      //console.log(docs);
      //获取分类
      var c1 = db.collection('cats');
      c1.find().toArray(function (err,result) {
        if (err) {
          res.send(err);
          return;
        }
        //res.send('ok');
        //console.log(result);
        //渲染后台首页面
        res.render('home/index', {data : docs, data1:result});

      });
    })
  });*/

  MongoClient.connect(DB_STR,function(err,db){
    if(err){
      res.send(err);
      return;
    }
    //获取文章
    var c = db.collection('posts');
    c.find().limit(2).toArray(function (err,docs) {
      if(err){
        res.send(err);
        return;
      }
      //console.log(docs);
      //获取分类
      var c1 = db.collection('cats');
      c1.find().toArray(function (err,result) {
        if (err) {
          res.send(err);
          return;
        }
        //res.send('ok');
        //console.log(result);
        //渲染后台首页面
        res.render('home/index', {data : docs, data1:result});

      });
    })
  });


});
//find().skip( (page -1) * pagesize ).limit(pagesize)
//分页功能
router.get('/page', function(req, res, next) {
  var page = req.query.page;
  console.log(page);
  //连接数据库,获取数据,显示到页面
  MongoClient.connect(DB_STR,function(err,db){
    if(err){
      res.send(err);
      return;
    }
    //获取文章
    var c = db.collection('posts');
    c.find().skip((page-1)*2).limit(2).toArray(function (err,docs) {
      if(err){
        res.send(err);
        return;
      }
      //console.log(docs);
      //获取分类
      var c1 = db.collection('cats');
      c1.find().toArray(function (err,result) {
        if (err) {
          res.send(err);
          return;
        }
        //res.send('ok');
        //console.log(result);
        //渲染后台首页面
        res.render('home/index', {data : docs, data1:result});

      });
    })
  });


});


module.exports = router;
