var express = require('express');
var path = require('path');
var favicon = require('serve-favicon');
var logger = require('morgan');
var cookieParser = require('cookie-parser');
var bodyParser = require('body-parser');
var app = express();
//引入session模块
var session = require('express-session');
app.use(session({
  secret:'blog_ime',//名字
  resave:false,
  saveUninitialized:true,
  cookie:{}//设置session有效期1h(不要设置secure:true)
}));


var routes = require('./routes/home/index');
var users = require('./routes/admin/users');
var posts = require('./routes/home/posts');

var admin = require('./routes/admin/admin');//载入admin.js模块
var cats = require('./routes/admin/cats');//载入cats.js模块
var artical = require('./routes/admin/posts');//载入posts.js模块

// view engine setup
app.set('views', path.join(__dirname, 'views'));

app.engine('html',require('ejs').__express);//????设置模板引擎的名字为html,本身还是基于ejs

app.set('view engine', 'html');

// uncomment after placing your favicon in /public
//app.use(favicon(path.join(__dirname, 'public', 'favicon.ico')));
app.use(logger('dev'));
app.use(bodyParser.json());
app.use(bodyParser.urlencoded({ extended: false }));
app.use(cookieParser());

app.use(express.static(path.join(__dirname, 'public')));
//解析后台的静态资源
app.use(express.static(path.join(__dirname, 'views/admin')));

app.use('/', routes);
//app.use('/users', users);
app.use('/posts', posts);
app.use('/admin/users',users);


app.use('/admin/index',checkLogin);
//使用后台首页的路由
app.use('/admin/index', admin);

app.use('/admin/cats',checkLogin);
//使用后台分类页的路由
app.use('/admin/cats',cats);
//使用后台分类页的路由
app.use('/admin/cats/add',cats);

app.use('/admin/posts',checkLogin);
//使用后台文章显示页的路由
app.use('/admin/posts',artical);


//判断是否有访问权
function checkLogin(req,res,next){
    if(!req.session.isLogin){
      res.redirect('/admin/users/login');
    }
  //把控制权转交
  next();
}

// catch 404 and forward to error handler
app.use(function(req, res, next) {
  var err = new Error('Not Found');
  err.status = 404;
  next(err);
});

// error handlers

// development error handler
// will print stacktrace
if (app.get('env') === 'development') {
  app.use(function(err, req, res, next) {
    res.status(err.status || 500);
    res.render('error', {
      message: err.message,
      error: err
    });
  });
}

// production error handler
// no stacktraces leaked to user
app.use(function(err, req, res, next) {
  res.status(err.status || 500);
  res.render('error',{
    message: err.message,
    error: {}
  });
});


module.exports = app;
